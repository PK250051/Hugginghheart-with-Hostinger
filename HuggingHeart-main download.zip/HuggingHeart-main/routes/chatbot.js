const express = require('express');
const router = express.Router();
const chatbotController = require('../controllers/chatbotController');
const { authenticate } = require('../middleware/auth');

// Public routes (chatbot doesn't require auth, but you can add it if needed)
router.get('/profiles', chatbotController.getProfiles);
router.get('/profiles/:id', chatbotController.getProfileById);
router.post('/response', chatbotController.getResponse);

// Admin route (optional - add admin middleware if needed)
// router.post('/responses', authenticate, chatbotController.addResponse);

module.exports = router;
