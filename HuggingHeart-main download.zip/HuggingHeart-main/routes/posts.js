const express = require('express');
const router = express.Router();
const postController = require('../controllers/postController');
const { authenticate } = require('../middleware/auth');
const upload = require('../middleware/upload');

// All routes require authentication
router.use(authenticate);

// Post routes
router.post('/', upload.single('image'), postController.createPost);
router.get('/feed', postController.getFeed);
router.get('/:id', postController.getPostById);
router.put('/:id', postController.updatePost);
router.delete('/:id', postController.deletePost);

// Like routes
router.post('/:id/like', postController.toggleLike);

// Comment routes
router.get('/:id/comments', postController.getComments);
router.post('/:id/comments', postController.addComment);
router.delete('/comments/:commentId', postController.deleteComment);

module.exports = router;
