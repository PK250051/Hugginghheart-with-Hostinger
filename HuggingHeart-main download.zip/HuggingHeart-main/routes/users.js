const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authenticate } = require('../middleware/auth');
const upload = require('../middleware/upload');

// Public routes
router.get('/:id', userController.getUserById);

// Protected routes
router.put('/profile', authenticate, upload.single('avatar'), userController.updateProfile);

module.exports = router;
