const Chatbot = require('../models/Chatbot');

// Get all chatbot profiles
exports.getProfiles = async (req, res) => {
    try {
        const profiles = await Chatbot.getProfiles();
        res.json({
            success: true,
            profiles
        });
    } catch (error) {
        console.error('Get chatbot profiles error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};

// Get chatbot profile by ID
exports.getProfileById = async (req, res) => {
    try {
        const profileId = req.params.id;
        const profile = await Chatbot.getProfileById(profileId);
        
        if (!profile) {
            return res.status(404).json({
                success: false,
                message: 'Chatbot profile not found'
            });
        }

        res.json({
            success: true,
            profile
        });
    } catch (error) {
        console.error('Get chatbot profile error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};

// Get chatbot response
exports.getResponse = async (req, res) => {
    try {
        const { message, profile_id } = req.body;

        if (!message || message.trim().length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Message is required'
            });
        }

        // Search for response in database
        const response = await Chatbot.searchResponse(message, profile_id || null);

        if (!response) {
            // Default response if no match found
            return res.json({
                success: true,
                response: "I'm not sure how to respond to that. Could you rephrase your question? 🌸",
                profile_id: profile_id || null
            });
        }

        // Replace {name} placeholder if profile_id is provided
        let finalResponse = response;
        if (profile_id) {
            const profile = await Chatbot.getProfileById(profile_id);
            if (profile) {
                finalResponse = response.replace(/{name}/g, profile.name);
            }
        }

        res.json({
            success: true,
            response: finalResponse,
            profile_id: profile_id || null
        });
    } catch (error) {
        console.error('Get chatbot response error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};

// Add chatbot response (admin function - optional)
exports.addResponse = async (req, res) => {
    try {
        const { question_text, question_keywords, response_text, profile_id, personality_type } = req.body;

        if (!question_text || !response_text) {
            return res.status(400).json({
                success: false,
                message: 'Question text and response text are required'
            });
        }

        const responseId = await Chatbot.addResponse({
            question_text,
            question_keywords,
            response_text,
            profile_id,
            personality_type
        });

        res.status(201).json({
            success: true,
            message: 'Chatbot response added successfully',
            response_id: responseId
        });
    } catch (error) {
        console.error('Add chatbot response error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};
