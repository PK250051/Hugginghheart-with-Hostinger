const Post = require('../models/Post');
const Like = require('../models/Like');
const Comment = require('../models/Comment');
const path = require('path');

// Create a new post
exports.createPost = async (req, res) => {
    try {
        const userId = req.user.id;
        const { content } = req.body;

        if (!content || content.trim().length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Post content is required'
            });
        }

        let image_url = null;
        if (req.file) {
            const baseUrl = req.protocol + '://' + req.get('host');
            image_url = baseUrl + '/uploads/' + req.file.filename;
        }

        const post = await Post.create({
            user_id: userId,
            content: content.trim(),
            image_url
        });

        res.status(201).json({
            success: true,
            message: 'Post created successfully',
            post
        });
    } catch (error) {
        console.error('Create post error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};

// Get all posts (feed)
exports.getFeed = async (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;
        const userId = req.user?.id;

        const posts = await Post.findAll(limit, offset);

        // Add like status for each post if user is authenticated
        const postsWithLikes = await Promise.all(posts.map(async (post) => {
            const isLiked = userId ? await Like.isLiked(post.id, userId) : false;
            return {
                ...post,
                isLiked
            };
        }));

        res.json({
            success: true,
            posts: postsWithLikes,
            pagination: {
                limit,
                offset,
                count: postsWithLikes.length
            }
        });
    } catch (error) {
        console.error('Get feed error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};

// Get post by ID
exports.getPostById = async (req, res) => {
    try {
        const postId = parseInt(req.params.id);
        const userId = req.user?.id;

        const post = await Post.findById(postId);
        if (!post) {
            return res.status(404).json({
                success: false,
                message: 'Post not found'
            });
        }

        const isLiked = userId ? await Like.isLiked(postId, userId) : false;

        res.json({
            success: true,
            post: {
                ...post,
                isLiked
            }
        });
    } catch (error) {
        console.error('Get post error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};

// Update post
exports.updatePost = async (req, res) => {
    try {
        const postId = parseInt(req.params.id);
        const userId = req.user.id;
        const { content } = req.body;

        if (!content || content.trim().length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Post content is required'
            });
        }

        const post = await Post.findById(postId);
        if (!post) {
            return res.status(404).json({
                success: false,
                message: 'Post not found'
            });
        }

        if (post.user_id !== userId) {
            return res.status(403).json({
                success: false,
                message: 'You can only edit your own posts'
            });
        }

        const updatedPost = await Post.update(postId, userId, content.trim());

        res.json({
            success: true,
            message: 'Post updated successfully',
            post: updatedPost
        });
    } catch (error) {
        console.error('Update post error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};

// Delete post
exports.deletePost = async (req, res) => {
    try {
        const postId = parseInt(req.params.id);
        const userId = req.user.id;

        const post = await Post.findById(postId);
        if (!post) {
            return res.status(404).json({
                success: false,
                message: 'Post not found'
            });
        }

        if (post.user_id !== userId) {
            return res.status(403).json({
                success: false,
                message: 'You can only delete your own posts'
            });
        }

        await Post.delete(postId, userId);

        res.json({
            success: true,
            message: 'Post deleted successfully'
        });
    } catch (error) {
        console.error('Delete post error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};

// Like/Unlike post
exports.toggleLike = async (req, res) => {
    try {
        const postId = parseInt(req.params.id);
        const userId = req.user.id;

        const post = await Post.findById(postId);
        if (!post) {
            return res.status(404).json({
                success: false,
                message: 'Post not found'
            });
        }

        const isLiked = await Like.isLiked(postId, userId);
        let liked = false;

        if (isLiked) {
            await Like.removeLike(postId, userId);
            await Post.decrementLikes(postId);
            liked = false;
        } else {
            await Like.addLike(postId, userId);
            await Post.incrementLikes(postId);
            liked = true;
        }

        const likesCount = await Like.getLikesCount(postId);

        res.json({
            success: true,
            liked,
            likesCount
        });
    } catch (error) {
        console.error('Toggle like error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};

// Get comments for a post
exports.getComments = async (req, res) => {
    try {
        const postId = parseInt(req.params.id);
        const limit = parseInt(req.query.limit) || 50;
        const offset = parseInt(req.query.offset) || 0;

        const post = await Post.findById(postId);
        if (!post) {
            return res.status(404).json({
                success: false,
                message: 'Post not found'
            });
        }

        const comments = await Comment.findByPostId(postId, limit, offset);

        res.json({
            success: true,
            comments,
            pagination: {
                limit,
                offset,
                count: comments.length
            }
        });
    } catch (error) {
        console.error('Get comments error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};

// Add comment to post
exports.addComment = async (req, res) => {
    try {
        const postId = parseInt(req.params.id);
        const userId = req.user.id;
        const { content } = req.body;

        if (!content || content.trim().length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Comment content is required'
            });
        }

        const post = await Post.findById(postId);
        if (!post) {
            return res.status(404).json({
                success: false,
                message: 'Post not found'
            });
        }

        const comment = await Comment.create({
            post_id: postId,
            user_id: userId,
            content: content.trim()
        });

        await Post.incrementComments(postId);

        res.status(201).json({
            success: true,
            message: 'Comment added successfully',
            comment
        });
    } catch (error) {
        console.error('Add comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};

// Delete comment
exports.deleteComment = async (req, res) => {
    try {
        const commentId = parseInt(req.params.commentId);
        const userId = req.user.id;

        const comment = await Comment.findById(commentId);
        if (!comment) {
            return res.status(404).json({
                success: false,
                message: 'Comment not found'
            });
        }

        if (comment.user_id !== userId) {
            return res.status(403).json({
                success: false,
                message: 'You can only delete your own comments'
            });
        }

        await Comment.delete(commentId, userId);

        res.json({
            success: true,
            message: 'Comment deleted successfully'
        });
    } catch (error) {
        console.error('Delete comment error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error. Please try again later.'
        });
    }
};
