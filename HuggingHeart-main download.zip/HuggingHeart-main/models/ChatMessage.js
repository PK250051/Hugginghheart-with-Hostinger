const db = require('../config/database');

class ChatMessage {
    // Create a new chat message
    static async create(messageData) {
        const { sender_id, receiver_id, message } = messageData;
        const [result] = await db.execute(
            'INSERT INTO chat_messages (sender_id, receiver_id, message) VALUES (?, ?, ?)',
            [sender_id, receiver_id, message]
        );
        return await this.findById(result.insertId);
    }

    // Find message by ID
    static async findById(id) {
        const [rows] = await db.execute(
            `SELECT m.*, u.name as sender_name, u.avatar_url as sender_avatar 
             FROM chat_messages m 
             JOIN users u ON m.sender_id = u.id 
             WHERE m.id = ?`,
            [id]
        );
        return rows[0] || null;
    }

    // Get conversation between two users
    static async getConversation(user1_id, user2_id, limit = 100, offset = 0) {
        const [rows] = await db.execute(
            `SELECT m.*, u.name as sender_name, u.avatar_url as sender_avatar 
             FROM chat_messages m 
             JOIN users u ON m.sender_id = u.id 
             WHERE (m.sender_id = ? AND m.receiver_id = ?) 
                OR (m.sender_id = ? AND m.receiver_id = ?)
             ORDER BY m.created_at ASC 
             LIMIT ? OFFSET ?`,
            [user1_id, user2_id, user2_id, user1_id, limit, offset]
        );
        return rows;
    }

    // Get user's recent conversations
    static async getRecentConversations(user_id, limit = 20) {
        const [rows] = await db.execute(
            `SELECT DISTINCT 
                CASE 
                    WHEN sender_id = ? THEN receiver_id 
                    ELSE sender_id 
                END as other_user_id,
                u.name as other_user_name,
                u.avatar_url as other_user_avatar,
                (SELECT message FROM chat_messages 
                 WHERE (sender_id = ? AND receiver_id = other_user_id) 
                    OR (sender_id = other_user_id AND receiver_id = ?)
                 ORDER BY created_at DESC LIMIT 1) as last_message,
                (SELECT created_at FROM chat_messages 
                 WHERE (sender_id = ? AND receiver_id = other_user_id) 
                    OR (sender_id = other_user_id AND receiver_id = ?)
                 ORDER BY created_at DESC LIMIT 1) as last_message_time
             FROM chat_messages m
             JOIN users u ON (
                 CASE 
                     WHEN m.sender_id = ? THEN m.receiver_id = u.id
                     ELSE m.sender_id = u.id
                 END
             )
             WHERE sender_id = ? OR receiver_id = ?
             GROUP BY other_user_id
             ORDER BY last_message_time DESC
             LIMIT ?`,
            [user_id, user_id, user_id, user_id, user_id, user_id, user_id, user_id, limit]
        );
        return rows;
    }
}

module.exports = ChatMessage;
