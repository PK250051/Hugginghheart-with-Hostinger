const db = require('../config/database');

class Comment {
    // Create a new comment
    static async create(commentData) {
        const { post_id, user_id, content } = commentData;
        const [result] = await db.execute(
            'INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)',
            [post_id, user_id, content]
        );
        return await this.findById(result.insertId);
    }

    // Find comment by ID
    static async findById(id) {
        const [rows] = await db.execute(
            `SELECT c.*, u.name as author_name, u.avatar_url as author_avatar 
             FROM comments c 
             JOIN users u ON c.user_id = u.id 
             WHERE c.id = ?`,
            [id]
        );
        return rows[0] || null;
    }

    // Get comments for a post
    static async findByPostId(post_id, limit = 50, offset = 0) {
        const [rows] = await db.execute(
            `SELECT c.*, u.name as author_name, u.avatar_url as author_avatar 
             FROM comments c 
             JOIN users u ON c.user_id = u.id 
             WHERE c.post_id = ? 
             ORDER BY c.created_at ASC 
             LIMIT ? OFFSET ?`,
            [post_id, limit, offset]
        );
        return rows;
    }

    // Delete comment
    static async delete(id, user_id) {
        const [result] = await db.execute(
            'DELETE FROM comments WHERE id = ? AND user_id = ?',
            [id, user_id]
        );
        return result.affectedRows > 0;
    }
}

module.exports = Comment;
