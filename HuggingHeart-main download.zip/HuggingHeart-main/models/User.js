const db = require('../config/database');

class User {
    // Create a new user
    static async create(userData) {
        const { name, email, password_hash, avatar_url, bio } = userData;
        const [result] = await db.execute(
            'INSERT INTO users (name, email, password_hash, avatar_url, bio) VALUES (?, ?, ?, ?, ?)',
            [name, email, password_hash, avatar_url || null, bio || null]
        );
        return result.insertId;
    }

    // Find user by email
    static async findByEmail(email) {
        const [rows] = await db.execute(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );
        return rows[0] || null;
    }

    // Find user by ID
    static async findById(id) {
        const [rows] = await db.execute(
            'SELECT id, name, email, avatar_url, bio, created_at FROM users WHERE id = ?',
            [id]
        );
        return rows[0] || null;
    }

    // Update user profile
    static async update(id, userData) {
        const { name, bio, avatar_url } = userData;
        const updates = [];
        const values = [];

        if (name !== undefined) {
            updates.push('name = ?');
            values.push(name);
        }
        if (bio !== undefined) {
            updates.push('bio = ?');
            values.push(bio);
        }
        if (avatar_url !== undefined) {
            updates.push('avatar_url = ?');
            values.push(avatar_url);
        }

        if (updates.length === 0) return null;

        values.push(id);
        await db.execute(
            `UPDATE users SET ${updates.join(', ')} WHERE id = ?`,
            values
        );
        return await this.findById(id);
    }

    // Update password
    static async updatePassword(id, password_hash) {
        await db.execute(
            'UPDATE users SET password_hash = ? WHERE id = ?',
            [password_hash, id]
        );
    }
}

module.exports = User;
