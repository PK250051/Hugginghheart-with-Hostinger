const db = require('../config/database');

class Chatbot {
    // Get all chatbot profiles
    static async getProfiles() {
        const [rows] = await db.execute(
            'SELECT * FROM chatbot_profiles WHERE is_active = TRUE ORDER BY id'
        );
        return rows;
    }

    // Get chatbot profile by ID
    static async getProfileById(id) {
        const [rows] = await db.execute(
            'SELECT * FROM chatbot_profiles WHERE id = ? AND is_active = TRUE',
            [id]
        );
        return rows[0] || null;
    }

    // Search for chatbot response
    static async searchResponse(userInput, profileId = null) {
        const searchText = userInput.toLowerCase().trim();
        
        // Build query with optional profile filter
        let query = `
            SELECT * FROM chatbot_responses 
            WHERE (
                question_text LIKE ? 
                OR question_keywords LIKE ?
                OR MATCH(question_text, response_text) AGAINST(? IN NATURAL LANGUAGE MODE)
            )
        `;
        const params = [`%${searchText}%`, `%${searchText}%`, searchText];

        if (profileId) {
            query += ' AND (profile_id = ? OR profile_id IS NULL)';
            params.push(profileId);
        } else {
            query += ' AND profile_id IS NULL';
        }

        query += ' ORDER BY profile_id DESC, id ASC LIMIT 1';

        const [rows] = await db.execute(query, params);
        
        if (rows.length > 0) {
            return rows[0].response_text;
        }

        // Fallback: Search by keywords
        const keywords = searchText.split(' ');
        for (const keyword of keywords) {
            if (keyword.length > 2) {
                const [fallbackRows] = await db.execute(
                    `SELECT * FROM chatbot_responses 
                     WHERE question_keywords LIKE ? 
                     AND (profile_id = ? OR profile_id IS NULL)
                     ORDER BY profile_id DESC LIMIT 1`,
                    [`%${keyword}%`, profileId || null]
                );
                if (fallbackRows.length > 0) {
                    return fallbackRows[0].response_text;
                }
            }
        }

        return null;
    }

    // Add chatbot response
    static async addResponse(responseData) {
        const { question_text, question_keywords, response_text, profile_id, personality_type } = responseData;
        const [result] = await db.execute(
            'INSERT INTO chatbot_responses (question_text, question_keywords, response_text, profile_id, personality_type) VALUES (?, ?, ?, ?, ?)',
            [question_text, question_keywords || null, response_text, profile_id || null, personality_type || null]
        );
        return result.insertId;
    }

    // Update chatbot response
    static async updateResponse(id, responseData) {
        const { question_text, question_keywords, response_text } = responseData;
        await db.execute(
            'UPDATE chatbot_responses SET question_text = ?, question_keywords = ?, response_text = ? WHERE id = ?',
            [question_text, question_keywords || null, response_text, id]
        );
    }

    // Get all responses (admin)
    static async getAllResponses(limit = 100, offset = 0) {
        const [rows] = await db.execute(
            'SELECT * FROM chatbot_responses ORDER BY created_at DESC LIMIT ? OFFSET ?',
            [limit, offset]
        );
        return rows;
    }
}

module.exports = Chatbot;
