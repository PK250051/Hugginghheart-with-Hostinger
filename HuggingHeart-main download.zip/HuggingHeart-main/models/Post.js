const db = require('../config/database');

class Post {
    // Create a new post
    static async create(postData) {
        const { user_id, content, image_url } = postData;
        const [result] = await db.execute(
            'INSERT INTO posts (user_id, content, image_url) VALUES (?, ?, ?)',
            [user_id, content, image_url || null]
        );
        return await this.findById(result.insertId);
    }

    // Find post by ID with user info
    static async findById(id) {
        const [rows] = await db.execute(
            `SELECT p.*, u.name as author_name, u.avatar_url as author_avatar 
             FROM posts p 
             JOIN users u ON p.user_id = u.id 
             WHERE p.id = ?`,
            [id]
        );
        return rows[0] || null;
    }

    // Get all posts with pagination
    static async findAll(limit = 50, offset = 0) {
        const [rows] = await db.execute(
            `SELECT p.*, u.name as author_name, u.avatar_url as author_avatar 
             FROM posts p 
             JOIN users u ON p.user_id = u.id 
             ORDER BY p.created_at DESC 
             LIMIT ? OFFSET ?`,
            [limit, offset]
        );
        return rows;
    }

    // Get posts by user ID
    static async findByUserId(user_id, limit = 50, offset = 0) {
        const [rows] = await db.execute(
            `SELECT p.*, u.name as author_name, u.avatar_url as author_avatar 
             FROM posts p 
             JOIN users u ON p.user_id = u.id 
             WHERE p.user_id = ? 
             ORDER BY p.created_at DESC 
             LIMIT ? OFFSET ?`,
            [user_id, limit, offset]
        );
        return rows;
    }

    // Update post
    static async update(id, user_id, content) {
        await db.execute(
            'UPDATE posts SET content = ? WHERE id = ? AND user_id = ?',
            [content, id, user_id]
        );
        return await this.findById(id);
    }

    // Delete post
    static async delete(id, user_id) {
        const [result] = await db.execute(
            'DELETE FROM posts WHERE id = ? AND user_id = ?',
            [id, user_id]
        );
        return result.affectedRows > 0;
    }

    // Increment likes count
    static async incrementLikes(id) {
        await db.execute(
            'UPDATE posts SET likes_count = likes_count + 1 WHERE id = ?',
            [id]
        );
    }

    // Decrement likes count
    static async decrementLikes(id) {
        await db.execute(
            'UPDATE posts SET likes_count = GREATEST(likes_count - 1, 0) WHERE id = ?',
            [id]
        );
    }

    // Increment comments count
    static async incrementComments(id) {
        await db.execute(
            'UPDATE posts SET comments_count = comments_count + 1 WHERE id = ?',
            [id]
        );
    }
}

module.exports = Post;
