const db = require('../config/database');

class Like {
    // Add like to post
    static async addLike(post_id, user_id) {
        try {
            await db.execute(
                'INSERT INTO likes (post_id, user_id) VALUES (?, ?)',
                [post_id, user_id]
            );
            return true;
        } catch (error) {
            if (error.code === 'ER_DUP_ENTRY') {
                return false; // Already liked
            }
            throw error;
        }
    }

    // Remove like from post
    static async removeLike(post_id, user_id) {
        const [result] = await db.execute(
            'DELETE FROM likes WHERE post_id = ? AND user_id = ?',
            [post_id, user_id]
        );
        return result.affectedRows > 0;
    }

    // Check if user liked a post
    static async isLiked(post_id, user_id) {
        const [rows] = await db.execute(
            'SELECT id FROM likes WHERE post_id = ? AND user_id = ?',
            [post_id, user_id]
        );
        return rows.length > 0;
    }

    // Get likes count for a post
    static async getLikesCount(post_id) {
        const [rows] = await db.execute(
            'SELECT COUNT(*) as count FROM likes WHERE post_id = ?',
            [post_id]
        );
        return rows[0].count;
    }

    // Get user's liked posts
    static async getUserLikedPosts(user_id, limit = 50, offset = 0) {
        const [rows] = await db.execute(
            `SELECT p.*, u.name as author_name, u.avatar_url as author_avatar 
             FROM posts p 
             JOIN users u ON p.user_id = u.id 
             JOIN likes l ON p.id = l.post_id 
             WHERE l.user_id = ? 
             ORDER BY l.created_at DESC 
             LIMIT ? OFFSET ?`,
            [user_id, limit, offset]
        );
        return rows;
    }
}

module.exports = Like;
