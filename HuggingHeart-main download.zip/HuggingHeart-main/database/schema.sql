-- HuggingHeart Database Schema
-- MySQL 5.7+ / MariaDB 10.3+

-- Create database
CREATE DATABASE IF NOT EXISTS huggingheart CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE huggingheart;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    avatar_url VARCHAR(500) DEFAULT NULL,
    bio TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Posts table
CREATE TABLE IF NOT EXISTS posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    content TEXT NOT NULL,
    image_url VARCHAR(500) DEFAULT NULL,
    likes_count INT DEFAULT 0,
    comments_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Comments table
CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    user_id INT NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_post_id (post_id),
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Likes table
CREATE TABLE IF NOT EXISTS likes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_like (post_id, user_id),
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_post_id (post_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Chat messages table (for real-time chat)
CREATE TABLE IF NOT EXISTS chat_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sender_receiver (sender_id, receiver_id),
    INDEX idx_receiver_created (receiver_id, created_at DESC),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Chatbot responses table (replaces CSV storage)
CREATE TABLE IF NOT EXISTS chatbot_responses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question_text VARCHAR(500) NOT NULL,
    question_keywords VARCHAR(500) DEFAULT NULL,
    response_text TEXT NOT NULL,
    profile_id VARCHAR(50) DEFAULT NULL,
    personality_type VARCHAR(50) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_question_keywords (question_keywords(255)),
    INDEX idx_profile_id (profile_id),
    INDEX idx_personality_type (personality_type),
    FULLTEXT idx_question_fulltext (question_text, response_text)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Chatbot profiles (Observer profiles like G001-G010)
CREATE TABLE IF NOT EXISTS chatbot_profiles (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    age INT DEFAULT NULL,
    location VARCHAR(255) DEFAULT NULL,
    role VARCHAR(255) DEFAULT NULL,
    personality_type VARCHAR(50) DEFAULT NULL,
    avatar_url VARCHAR(500) DEFAULT NULL,
    bio TEXT DEFAULT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default chatbot profiles (Observers)
INSERT INTO chatbot_profiles (id, name, age, location, role, personality_type, avatar_url, bio) VALUES
('G001', 'Luna Sharma', 24, 'Mumbai', 'Software Engineer', 'Bold Strategist', '/assets/images/girls/G001_luna.jpg', 'Tech enthusiast with a love for deep logic and late-night philosophy.'),
('G002', 'Meera Iyer', 26, 'Bangalore', 'UX Researcher', 'The Caretaker', '/assets/images/girls/G002_meera.jpg', 'Fascinated by human behavior and digital empathy.'),
('G003', 'Ananya Rai', 21, 'Delhi', 'Digital Artist', 'Creative Soul', '/assets/images/girls/G003_ananya.jpg', 'I see the world in colors and believe every pixel tells a story.'),
('G004', 'Isha Verma', 23, 'Pune', 'Data Scientist', 'The Analyst', '/assets/images/girls/G004_isha.jpg', 'Searching for patterns in the chaos and beauty in numbers.'),
('G005', 'Riya Kapoor', 24, 'Chennai', 'Designer', 'The Techie', '/assets/images/girls/G005_riya.jpg', 'Blending tech logic with modern style.'),
('G006', 'Sofia Verma', 20, 'Sydney', 'HR Executive', 'Gentle Caretaker', '/assets/images/girls/G006_sofia.jpg', 'Focused on helping others find their true path in life.'),
('G007', 'Olivia Singh', 22, 'Toronto', 'Strategic Analyst', 'The Strategist', '/assets/images/girls/G007_olivia.jpg', 'Maintains a perfect work-life balance and values clear minds.'),
('G008', 'Aarohi Gupta', 30, 'Hyderabad', 'Content Writer', 'Intellectual', '/assets/images/girls/G008_aarohi.jpg', 'Words are my soul. I find peace in quiet libraries.'),
('G009', 'Emma Watson', 25, 'London', 'Operations Lead', 'Efficient Leader', '/assets/images/girls/G009_emma.jpg', 'Always looking for the most efficient path forward.'),
('G010', 'Amelia Chen', 22, 'Singapore', 'Frontend Dev', 'Globalist', '/assets/images/girls/G010_amelia.jpg', 'Building beautiful interfaces for a more connected world.')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- Insert sample chatbot responses
INSERT INTO chatbot_responses (question_text, question_keywords, response_text, profile_id, personality_type) VALUES
('how are you', 'how are you, how are you doing, how are you today', 'I''m doing great, thank you for asking! How about you? How can I help you today?', NULL, NULL),
('what is your name', 'what is your name, what''s your name, who are you', 'My name is {name}! It''s so nice to meet you. What''s your name?', NULL, NULL),
('hello', 'hello, hi, hey, greetings', 'Hello! Welcome to HuggingHeart. How can I help you today?', NULL, NULL),
('goodbye', 'goodbye, bye, see you, farewell', 'Goodbye! It was nice chatting with you. Feel free to come back anytime!', NULL, NULL),
('tell me about yourself', 'tell me about yourself, about you, who are you', 'I''m here to help you have meaningful conversations and connect with others on HuggingHeart. What would you like to know?', NULL, NULL)
ON DUPLICATE KEY UPDATE response_text=VALUES(response_text);
