/**
 * HuggingHeart API Client
 * 
 * This file provides a JavaScript API client for interacting with the HuggingHeart backend.
 * Use this in your frontend HTML files to make API calls.
 */

// API Configuration
const API_CONFIG = {
    baseURL: window.location.origin + '/api',
    // Or set explicitly: baseURL: 'http://localhost:3000/api'
    tokenKey: 'hh_jwt_token',
    userKey: 'hh_user_data'
};

/**
 * Get stored JWT token
 */
function getToken() {
    return localStorage.getItem(API_CONFIG.tokenKey);
}

/**
 * Store JWT token
 */
function setToken(token) {
    localStorage.setItem(API_CONFIG.tokenKey, token);
}

/**
 * Remove JWT token (logout)
 */
function removeToken() {
    localStorage.removeItem(API_CONFIG.tokenKey);
    localStorage.removeItem(API_CONFIG.userKey);
}

/**
 * Get stored user data
 */
function getUser() {
    const userData = localStorage.getItem(API_CONFIG.userKey);
    return userData ? JSON.parse(userData) : null;
}

/**
 * Store user data
 */
function setUser(user) {
    localStorage.setItem(API_CONFIG.userKey, JSON.stringify(user));
}

/**
 * Check if user is authenticated
 */
function isAuthenticated() {
    return !!getToken();
}

/**
 * Make API request
 */
async function apiRequest(endpoint, options = {}) {
    const url = `${API_CONFIG.baseURL}${endpoint}`;
    const token = getToken();

    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
        }
    };

    // Add authorization header if token exists
    if (token) {
        defaultOptions.headers['Authorization'] = `Bearer ${token}`;
    }

    // Merge options
    const finalOptions = {
        ...defaultOptions,
        ...options,
        headers: {
            ...defaultOptions.headers,
            ...(options.headers || {})
        }
    };

    try {
        const response = await fetch(url, finalOptions);
        const data = await response.json();

        // Handle 401 Unauthorized (token expired)
        if (response.status === 401) {
            removeToken();
            if (window.location.pathname !== '/signin.html') {
                window.location.href = '/signin.html';
            }
            throw new Error(data.message || 'Authentication required');
        }

        if (!response.ok) {
            throw new Error(data.message || 'API request failed');
        }

        return data;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

/**
 * Authentication API
 */
const AuthAPI = {
    /**
     * Register new user
     */
    async register(name, email, password) {
        const response = await apiRequest('/auth/register', {
            method: 'POST',
            body: JSON.stringify({ name, email, password })
        });

        if (response.success && response.token) {
            setToken(response.token);
            setUser(response.user);
        }

        return response;
    },

    /**
     * Login user
     */
    async login(email, password) {
        const response = await apiRequest('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });

        if (response.success && response.token) {
            setToken(response.token);
            setUser(response.user);
        }

        return response;
    },

    /**
     * Logout user
     */
    logout() {
        removeToken();
        window.location.href = '/signin.html';
    },

    /**
     * Get current user profile
     */
    async getProfile() {
        return await apiRequest('/auth/profile');
    }
};

/**
 * User API
 */
const UserAPI = {
    /**
     * Get user by ID
     */
    async getUserById(id) {
        return await apiRequest(`/users/${id}`);
    },

    /**
     * Update user profile
     */
    async updateProfile(data) {
        const formData = new FormData();
        
        if (data.name) formData.append('name', data.name);
        if (data.bio) formData.append('bio', data.bio);
        if (data.avatar) formData.append('avatar', data.avatar);

        const token = getToken();
        const response = await fetch(`${API_CONFIG.baseURL}/users/profile`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${token}`
            },
            body: formData
        });

        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.message || 'Failed to update profile');
        }

        if (result.success && result.user) {
            setUser(result.user);
        }

        return result;
    }
};

/**
 * Post API
 */
const PostAPI = {
    /**
     * Create a new post
     */
    async createPost(content, imageFile = null) {
        const formData = new FormData();
        formData.append('content', content);
        if (imageFile) {
            formData.append('image', imageFile);
        }

        const token = getToken();
        const response = await fetch(`${API_CONFIG.baseURL}/posts`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            },
            body: formData
        });

        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || 'Failed to create post');
        }

        return result;
    },

    /**
     * Get feed (all posts)
     */
    async getFeed(limit = 50, offset = 0) {
        return await apiRequest(`/posts/feed?limit=${limit}&offset=${offset}`);
    },

    /**
     * Get post by ID
     */
    async getPostById(id) {
        return await apiRequest(`/posts/${id}`);
    },

    /**
     * Update post
     */
    async updatePost(id, content) {
        return await apiRequest(`/posts/${id}`, {
            method: 'PUT',
            body: JSON.stringify({ content })
        });
    },

    /**
     * Delete post
     */
    async deletePost(id) {
        return await apiRequest(`/posts/${id}`, {
            method: 'DELETE'
        });
    },

    /**
     * Like/unlike post
     */
    async toggleLike(id) {
        return await apiRequest(`/posts/${id}/like`, {
            method: 'POST'
        });
    },

    /**
     * Get comments for a post
     */
    async getComments(postId, limit = 50, offset = 0) {
        return await apiRequest(`/posts/${postId}/comments?limit=${limit}&offset=${offset}`);
    },

    /**
     * Add comment to post
     */
    async addComment(postId, content) {
        return await apiRequest(`/posts/${postId}/comments`, {
            method: 'POST',
            body: JSON.stringify({ content })
        });
    },

    /**
     * Delete comment
     */
    async deleteComment(commentId) {
        return await apiRequest(`/posts/comments/${commentId}`, {
            method: 'DELETE'
        });
    }
};

/**
 * Chatbot API
 */
const ChatbotAPI = {
    /**
     * Get all chatbot profiles
     */
    async getProfiles() {
        return await apiRequest('/chatbot/profiles');
    },

    /**
     * Get chatbot profile by ID
     */
    async getProfileById(id) {
        return await apiRequest(`/chatbot/profiles/${id}`);
    },

    /**
     * Get chatbot response
     */
    async getResponse(message, profileId = null) {
        return await apiRequest('/chatbot/response', {
            method: 'POST',
            body: JSON.stringify({ message, profile_id: profileId })
        });
    }
};

/**
 * Socket.io Client Setup
 * 
 * Usage:
 *   const socket = setupSocket();
 *   socket.on('receive_message', (data) => { ... });
 *   socket.emit('send_message', { receiver_id: 2, message: 'Hello' });
 */
function setupSocket() {
    const token = getToken();
    const socket = io(window.location.origin, {
        auth: {
            token: token
        }
    });

    socket.on('connect', () => {
        console.log('Socket connected');
    });

    socket.on('disconnect', () => {
        console.log('Socket disconnected');
    });

    socket.on('error', (error) => {
        console.error('Socket error:', error);
    });

    return socket;
}

// Export APIs (for use in other scripts)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        AuthAPI,
        UserAPI,
        PostAPI,
        ChatbotAPI,
        setupSocket,
        getToken,
        setToken,
        removeToken,
        getUser,
        setUser,
        isAuthenticated
    };
}

// Make APIs globally available
window.AuthAPI = AuthAPI;
window.UserAPI = UserAPI;
window.PostAPI = PostAPI;
window.ChatbotAPI = ChatbotAPI;
window.setupSocket = setupSocket;
window.isAuthenticated = isAuthenticated;
window.getUser = getUser;
